box_initial_position {0.3,1.45,1.55}
box_final_position {0.4,0.4,1.0}
