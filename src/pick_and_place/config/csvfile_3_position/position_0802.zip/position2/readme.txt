box_initial_position {-0.3,1.45,1.55}
box_final_position {-0.6,0,0.9}
